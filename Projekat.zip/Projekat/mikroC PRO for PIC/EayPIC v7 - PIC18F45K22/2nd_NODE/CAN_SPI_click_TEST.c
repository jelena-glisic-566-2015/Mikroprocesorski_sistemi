/**************************************************************************************************
 * Project name:
     CAN_SPI_click 2nd NODE (Demonstration of mikroBUS CAN SPI click board)
 * Copyright:
     (c) Mikroelektronika, 2011.
 * Revision History:
     20111228:
       - initial release (DA & JK);
 * Description:
     This is code that shows simple connection of two CAN SPI modules. This is for 2nd node.
     Press buttons on PortB to send message and receive message on PortD LEDs.

 * Test configuration:
     MCU:             PIC18F45K22
                      http://ww1.microchip.com/downloads/en/DeviceDoc/41412D.pdf
     dev.board:       EasyPIC7
                      http://www.mikroe.com/eng/products/view/757/easypic-v7-development-system/
     Oscillator:      HS-PLL 32.0000 MHz, 8.0000 MHz Crystal
     ext. modules:    can spi click 3.3v   ac:CAN_SPI_3.3
                      http://www.mikroe.com/eng/products/view/813/can-spi-click-3-3v/
                      with  SN65HVD230 on board:
                      http://www.ti.com/product/sn65hvd230
     SW:              mikroC PRO for PIC
                      http://www.mikroe.com/eng/products/view/7/mikroc-pro-for-pic/

 * NOTES:
     - Place jumper J5 to select 3.3V power supply voltage level.
     - Plug CAN SPI Board to mikroBUS 1 socket
     - Turn On PortD LEDs (SW3.4)
     - Turn On PortE LEDs (SW3.1)
     - Set pull-up on PortB (PortB three state switch)
     - Place jumper J17 in lower position.
**************************************************************************************************/

/**************************************************************************************************
* Global variables
**************************************************************************************************/
unsigned char Can_Init_Flags, Can_Send_Flags, Can_Rcv_Flags;                  // can flags
unsigned char Rx_Data_Len;                                                    // received data length in bytes
char RxTx_Data[8];                                                            // can rx/tx data buffer
char Msg_Rcvd;                                                                // reception flag
const long ID_1st = 12111, ID_2nd = 3;                                        // node IDs
long Rx_ID;

/**************************************************************************************************
* CAN SPI connections
**************************************************************************************************/
sbit CanSpi_CS            at  LATE0_bit;
sbit CanSpi_CS_Direction  at  TRISE0_bit;
sbit CanSpi_Rst           at  LATE1_bit;
sbit CanSpi_Rst_Direction at  TRISE1_bit;

/**************************************************************************************************
* Define TX LED indicator
**************************************************************************************************/
sbit TX_LED_dir at TRISE2_bit;
sbit TX_LED at LATE2_bit;

/**************************************************************************************************
* Port read variables
**************************************************************************************************/
char port_rd;
char port_rd_temp;

/**************************************************************************************************
* MAIN PROGRAM
**************************************************************************************************/
void main() {                     // Main Program

  ANSELA = 0;                     // Configure PORTA pins as digital
  ANSELB = 0;                     // Configure PORTB pins as digital
  ANSELC = 0;                     // Configure PORTC pins as digital
  ANSELD = 0;                     // Configure PORTD pins as digital
  ANSELE = 0;                     // Configure PORTE pins as digital

  SLRCON = 0;                     // Configure all PORTS at the standard Slew

  PORTD = 0;                      // clear PORTD
  TRISD = 0;                      // set PORTD as output

  CanSpi_CS_Direction = 0;
  CanSpi_Rst_Direction = 0;
  TX_LED_dir = 0;

  port_rd = 0;
  port_rd_temp = 0xff;
  
  Can_Init_Flags = 0;
  Can_Send_Flags = 0;                                                         // clear flags
  Can_Rcv_Flags  = 0;

  Can_Send_Flags = _CANSPI_TX_PRIORITY_0 &                                    // form value to be used
                   _CANSPI_TX_XTD_FRAME &                                     // with CANSPIWrite
                   _CANSPI_TX_NO_RTR_FRAME;

  Can_Init_Flags = _CANSPI_CONFIG_SAMPLE_THRICE &                             // form value to be used
                   _CANSPI_CONFIG_PHSEG2_PRG_ON &                             // with CANSPIInit
                   _CANSPI_CONFIG_XTD_MSG &
                   _CANSPI_CONFIG_DBL_BUFFER_ON &
                   _CANSPI_CONFIG_VALID_XTD_MSG &
                   _CANSPI_CONFIG_LINE_FILTER_OFF;

  // initialize SPI1 module
  SPI1_Init_Advanced(_SPI_MASTER_OSC_DIV16, _SPI_DATA_SAMPLE_MIDDLE, _SPI_CLK_IDLE_LOW, _SPI_LOW_2_HIGH);                                                               // initialize SPI1 module

  // Focs = 10MHz, SJW = 1, PHSEG1 = 3, PHSEG2 = 3, PROPSEG = 1, -> N = 1+3+3+1, N = 8
  // Desired Baud rate Fbaud = 125kb/s
  // BRP = Fosc/(2*N*Fbaud) = 5
  CANSPIInitialize(1,5,3,3,1,Can_Init_Flags);                                 // initialize external CANSPI module
  CANSPISetOperationMode(_CANSPI_MODE_CONFIG,0xFF);                           // set CONFIGURATION mode
  CANSPISetMask(_CANSPI_MASK_B1,-1,_CANSPI_CONFIG_XTD_MSG);                   // set all mask1 bits to ones
  CANSPISetMask(_CANSPI_MASK_B2,-1,_CANSPI_CONFIG_XTD_MSG);                   // set all mask2 bits to ones
  CANSPISetFilter(_CANSPI_FILTER_B2_F3,ID_1st,_CANSPI_CONFIG_XTD_MSG);        // set id of filter B2_F3 to 1st node ID

  CANSPISetOperationMode(_CANSPI_MODE_NORMAL,0xFF);                           // set NORMAL mode

  while(1)
  {                                                                           // endless loop
    Msg_Rcvd = CANSPIRead(&Rx_ID , RxTx_Data , &Rx_Data_Len, &Can_Rcv_Flags); // receive message

    if ((Rx_ID == ID_1st) && Msg_Rcvd) {                                      // if message received check id
      LATD = RxTx_Data[0];                                                    // id correct, output data at PORTD
      Delay_ms(10);
    }

    port_rd = PORTB;                                                          // Read value from PORTB
    if (port_rd != port_rd_temp)                                              // Check for change on PORTB
    {
       TX_LED = 1;                                                            // Turn ON TX LED indicator
       port_rd_temp = port_rd;                                                // Save current port value

       port_rd = ~port_rd;
       CANSPIWrite(ID_2nd, &port_rd, 1, Can_Send_Flags);                      // send incremented data back
       TX_LED = 0;                                                            // Turn OFF TX LED indicator
    }
  }
}

/**************************************************************************************************
* End of File
**************************************************************************************************/